import mysql.connector
from flask import Flask, flash, redirect, render_template, request, url_for

app = Flask(__name__)

db_config = {
    'host': 'localhost',
    'user': 'bhanu',
    'password': 'password',
    'database': 'registration'
}

@app.route('/')
def home():
    message = request.args.get('message')
    return render_template('index.html', message=message)

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form['name']
    email = request.form['email']
    age = request.form['age']
    dob = request.form['dob']
    if not name or not email or not age or not dob:
        flash("All fields are required!")
        return redirect(url_for('home'))
    try:
        age = int(age)
        if age <= 0:
            raise ValueError
    except ValueError:
        flash("Age must be a positive integer!")
        return redirect(url_for('home'))

    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO user_data (name, email, age, dob) VALUES (%s, %s, %s, %s)',
                   (name, email, age, dob))
    conn.commit()
    conn.close()

    return redirect(url_for('home', message="Thanks for filling the form!"))

@app.route('/users')
def users():
    conn = mysql.connector.connect(**db_config)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM user_data')
    users = cursor.fetchall()
    conn.close()
    return render_template('users.html', user_data=user_data)

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)
